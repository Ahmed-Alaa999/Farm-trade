package com.farmtrade.game

/** kind: 0 فاكهة, 1 خضار, 2 ورد. wiltMin = الدقائق بدون ماء حتى الموت (الورد أسرع ذبولاً) */
data class Plant(val id: Int, val name: String, val emoji: String, val kind: Int,
                 val growMin: Int, val wiltMin: Int, val seed: Int) {
    val sell get() = seed * 2 + 2
}

object Plants {
    private val raw = listOf(
        "تفاح|🍎|0|12|300|10", "موز|🍌|0|10|240|9", "عنب|🍇|0|14|200|12", "فراولة|🍓|0|8|150|8",
        "برتقال|🍊|0|13|360|11", "ليمون|🍋|0|11|420|9", "بطيخ|🍉|0|20|180|18", "خوخ|🍑|0|15|220|14",
        "كرز|🍒|0|9|160|10", "أناناس|🍍|0|25|480|25", "مانجو|🥭|0|22|400|22", "كيوي|🥝|0|16|260|16",
        "شمام|🍈|0|18|200|17", "كمثرى|🍐|0|12|320|10",
        "طماطم|🍅|1|6|240|6", "جزر|🥕|1|5|480|5", "ذرة|🌽|1|9|300|8", "بطاطس|🥔|1|7|600|6",
        "فلفل|🌶️|1|8|260|9", "خيار|🥒|1|5|180|5", "بروكلي|🥦|1|10|200|10", "ثوم|🧄|1|6|540|7",
        "بصل|🧅|1|6|560|6", "باذنجان|🍆|1|9|280|9", "خس|🥬|1|4|120|4", "فطر|🍄|1|5|100|8",
        "فول سوداني|🥜|1|11|420|11", "قرع|🎃|1|15|500|15",
        "وردة|🌹|2|8|90|12", "توليب|🌷|2|6|80|10", "عباد الشمس|🌻|2|10|150|9", "زهرة الكرز|🌸|2|9|100|11",
        "بابونج|🌼|2|5|70|6", "ياسمين|💮|2|7|75|8", "هيبيسكس|🌺|2|8|95|10", "قرنفل|🏵️|2|7|110|9",
        "باقة|💐|2|12|85|15", "نفل|🍀|2|4|130|5", "ريحان|🌿|2|3|160|4", "سنبل|🌾|2|6|120|7"
    )
    val all: List<Plant> = raw.mapIndexed { i, s ->
        val p = s.split("|")
        Plant(i, p[0], p[1], p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt())
    }
}

/** حالات: 0 ينمو، 1 جاهز، 2 عطشان، 3 ميت  → state*1000 + نسبة النمو */
object Native {
    private var ok = false
    init { try { System.loadLibrary("farmcore"); ok = true } catch (_: Throwable) {} }
    private external fun status(now: Long, planted: Long, watered: Long, grow: Long, wilt: Long): Int

    fun calc(now: Long, planted: Long, watered: Long, grow: Long, wilt: Long): Int {
        if (ok) try { return status(now, planted, watered, grow, wilt) } catch (_: Throwable) {}
        val dry = now - watered
        val pct = ((now - planted) * 100 / maxOf(grow, 1)).coerceIn(0, 100).toInt()
        val s = when { dry > wilt -> 3; dry > wilt / 2 -> 2; pct >= 100 -> 1; else -> 0 }
        return s * 1000 + pct
    }
}
