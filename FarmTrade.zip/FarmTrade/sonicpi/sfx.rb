# Sonic Pi: شغّل كل مقطع لوحده، اضغط Rec لتسجيله، احفظه wav بالاسم المذكور
# ثم ضعه في app/src/main/res/raw/  (الأسماء: sfx_plant, sfx_water, sfx_harvest, sfx_sell, sfx_buy, sfx_alarm)

# --- sfx_plant ---
use_synth :pluck; play :c3; sleep 0.1; play :e3

# --- sfx_water ---
use_synth :noise; with_fx(:hpf, cutoff: 100) { play 0, release: 0.5, amp: 0.4 }

# --- sfx_harvest ---
use_synth :pretty_bell; play_pattern_timed [:c5, :e5, :g5], 0.08

# --- sfx_sell (عملات) ---
use_synth :pretty_bell; play :e6; sleep 0.07; play :b6, release: 0.6

# --- sfx_buy ---
use_synth :beep; play_pattern_timed [:g4, :c5], 0.1

# --- sfx_alarm (مشكلة) ---
use_synth :saw; 3.times { play :a4, release: 0.15, amp: 0.5; sleep 0.2 }
